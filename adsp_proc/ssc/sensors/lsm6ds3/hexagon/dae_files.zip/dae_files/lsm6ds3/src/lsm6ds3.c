/** ======================================================================================
  @file lsm6ds3.c

  @brief lsm6ds3 data acquisition HAL

  Copyright (c) 2016-2017 Qualcomm Technologies, Inc.
  All Rights Reserved.
  Confidential and Proprietary - Qualcomm Technologies, Inc.

  $Id:  $
  $DateTime:  $
  $Change:  $
====================================================================================== **/

/**
*****************************************************************************************
                               Includes
*****************************************************************************************
*/
#include <stdbool.h>
#include "sns_dd_if.h"
#include "sns_macros.h"

/**
*****************************************************************************************
                               Constants/Macros
*****************************************************************************************
*/
#define STM_LSM6DS3_REG_FIFO_CTRL5        (0x0A)
#define STM_LSM6DS3_REG_CTRL1_A           (0x10)
#define STM_LSM6DS3_REG_CTRL2_G           (0x11)
#define STM_LSM6DS3_REG_WAKE_SRC          (0x1B)
#define STM_LSM6DS3_REG_OUT_X_L_XL        (0x28)
#define STM_LSM6DS3_REG_FIFO_STATUS1      (0x3A)
#define STM_LSM6DS3_REG_FIFO_DATA_OUT_L   (0x3E)

/**
*****************************************************************************************
                                  Static Functions
*****************************************************************************************
*/

static sns_com_port_status_e
lsm6ds3_get_data( sns_dd_handle_s*    dd_handle,
                  read_sensor_data    data_read_fptr,
                  notify_interrupt    notify_int_fptr,
                  int32_t             acc_delay,
                  int32_t*            delay_us,
                  bool*               call_again,
                  int32_t*            num_samples )
{
  sns_com_port_status_e status;
  uint8_t fifo_mode = 0;
  uint8_t fifo_status[4] = {0};
  uint8_t wake_src = 0;

  /* Registers to read into Data Acquisition buffer */
  sns_com_port_data_vector_s data_vectors[3] = 
  {
    { .reg_addr = STM_LSM6DS3_REG_CTRL1_A,
      .buf_sz = 1 },
    { .reg_addr = STM_LSM6DS3_REG_CTRL2_G,
      .buf_sz = 1 },
  };
      
  /* Status registers for use in this function */
  sns_com_port_vector_s state_vector_ptr[] =
  {
    { 
      .reg_addr = STM_LSM6DS3_REG_WAKE_SRC,
      .buf_sz = 1,
      .buf = &wake_src },
    { 
      .reg_addr = STM_LSM6DS3_REG_FIFO_STATUS1,
      .buf_sz = 4,
      .buf = fifo_status },
    {
      .reg_addr = STM_LSM6DS3_REG_FIFO_CTRL5,
      .buf_sz = 1,
      .buf = &fifo_mode },
  };

  /* Read the status registers */
  status = sns_com_port_read_reg_v( dd_handle, state_vector_ptr, 3 );
      
  if( status == SNS_COM_PORT_STATUS_SUCCESS )
  {
    if( fifo_mode != 0 )
    {
      uint16_t count_h = fifo_status[1] & 0x0F;
      uint16_t count_l = fifo_status[0] & 0xFF;
      uint16_t num_bytes =  (((count_h << 8) & 0xFF00) | count_l) * 2;

      data_vectors[2].reg_addr = STM_LSM6DS3_REG_FIFO_DATA_OUT_L;
      data_vectors[2].buf_sz = num_bytes;      
      
      *num_samples = num_bytes / 6;
    }
    else
    {
      /* FIFO disabled, read from accel registers */
      data_vectors[2].reg_addr = STM_LSM6DS3_REG_OUT_X_L_XL;
      data_vectors[2].buf_sz = 6;
      *num_samples = 1;
    }
    if( *num_samples > 0 )
    {
      status = data_read_fptr(dd_handle, data_vectors, ARR_SIZE(data_vectors));
      *delay_us = 0;
      *call_again = false;
    }

    wake_src &= ~0x7;
    if( wake_src != 0 )
    {
      uint8_t regvals[8] = {0};
      regvals[0] = wake_src;
      notify_int_fptr(dd_handle, regvals);
    }
  }
  return status;
}


/* ------------------------------------------------------------------------------------ */
static sns_com_port_status_e
lsm6ds3_parse_accel_data( sns_dd_handle_s*    dd_handle,
                          uint8_t const*      data_ptr,
                          uint16_t            data_bytes,
                          notify_accel_data       notify_data_fptr,
                          notify_accel_sample_cnt notify_cnt_fptr )
{
  int i;
  bool gyro_data_in_buffer;
  sns_com_port_status_e rv = SNS_COM_PORT_STATUS_ERROR;
  int32_t sample_count;
  int32_t sample_size = 6;
  int32_t loop_start = 2;
  if( data_bytes >= 8 )
  {
    gyro_data_in_buffer = ((data_ptr[1] & 0xF0) != 0);
      if(gyro_data_in_buffer)
      {
      sample_size = 12;
      loop_start = 8;
      }
    sample_count = (data_bytes-2)/sample_size;
    notify_cnt_fptr( dd_handle, sample_count );
    for(i = 2; i < data_bytes; i += sample_size)
    {
      int16_t x,y,z;
      x = ((data_ptr[i+1] << 8) | data_ptr[i+0]);
      y = ((data_ptr[i+3] << 8) | data_ptr[i+2]);
      z = ((data_ptr[i+5] << 8) | data_ptr[i+4]);
      notify_data_fptr( dd_handle, x, y, z );
    }
    rv = SNS_COM_PORT_STATUS_SUCCESS;
  }
  return  rv;
}

/**
*****************************************************************************************
                            Global Function Pointer Table
*****************************************************************************************
*/

sns_dd_if_s lsm6ds3_hal_table =
  { .get_data = lsm6ds3_get_data,
    .parse_accel_data = lsm6ds3_parse_accel_data };

